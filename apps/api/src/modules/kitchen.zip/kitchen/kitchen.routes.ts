import { Router } from "express";
import { getAuth } from "@clerk/express";
import { prisma } from "../../lib/prisma.js";
import { requireAuth } from "../../middleware/require-auth.js";
import type { Server } from "socket.io";
const kitchenRouter = Router();

const ACTIVE_KITCHEN_STATUSES = [
  "PLACED",
  "ACCEPTED",
  "PREPARING",
  "READY",
  "AWAITING_DELIVERY_PARTNER",
] as const;
const ALLOWED_STATUS_TRANSITIONS: Record<string, readonly string[]> = {
  PLACED: ["ACCEPTED", "CANCELLED"],
  ACCEPTED: ["PREPARING", "CANCELLED"],
  PREPARING: ["READY", "CANCELLED"],
  READY: ["AWAITING_DELIVERY_PARTNER", "HANDED_OFF", "CANCELLED"],
  AWAITING_DELIVERY_PARTNER: ["HANDED_OFF", "CANCELLED"],
  HANDED_OFF: [],
  CANCELLED: [],
};

// GET /api/kitchen/orders
// Fetch real customer orders for the staff member's assigned outlet(s).
kitchenRouter.get("/orders", requireAuth, async (req, res, next) => {
  try {
    const { userId: clerkUserId } = getAuth(req);

    if (!clerkUserId) {
      res.status(401).json({
        success: false,
        message: "Authentication required.",
      });
      return;
    }

    // Resolve Clerk identity to the internal database user.
    const user = await prisma.user.findUnique({
      where: {
        clerkUserId,
      },
      select: {
        id: true,
        isActive: true,
        outletStaff: {
          where: {
            isActive: true,
            role: {
              in: ["MANAGER", "KITCHEN_STAFF"],
            },
          },
          select: {
            outletId: true,
            role: true,
            outlet: {
              select: {
                id: true,
                name: true,
                code: true,
                minimumPrepTimeMin: true,
              },
            },
          },
        },
      },
    });

    if (!user || !user.isActive) {
      res.status(403).json({
        success: false,
        message: "Active staff profile required.",
      });
      return;
    }

    const staffOutlets = user.outletStaff;

    if (staffOutlets.length === 0) {
      res.status(403).json({
        success: false,
        message: "No active kitchen outlet assignment found.",
      });
      return;
    }

    const outletIds = staffOutlets.map((assignment) => assignment.outletId);

    // Read the same Order records created by POST /api/orders.
    // Scope them to outlets assigned to this staff member.
    const orders = await prisma.order.findMany({
      where: {
        outletId: {
          in: outletIds,
        },
        status: {
          in: [...ACTIVE_KITCHEN_STATUSES],
        },
      },
      orderBy: {
        placedAt: "asc",
      },
      include: {
        outlet: {
          select: {
            id: true,
            name: true,
            code: true,
            minimumPrepTimeMin: true,
          },
        },
        items: {
          include: {
            addons: true,
          },
        },
        statusHistory: {
          orderBy: {
            createdAt: "asc",
          },
        },
        prepTimeEstimates: {
          orderBy: {
            estimatedAt: "desc",
          },
          take: 1,
        },
      },
    });

    res.status(200).json({
      success: true,
      orders,
    });
  } catch (error) {
    next(error);
  }
});
// PATCH /api/kitchen/orders/:orderId/status
// Update order status and record the change in status history.
kitchenRouter.patch(
  "/orders/:orderId/status",
  requireAuth,
  async (req, res, next) => {
    try {
      const { userId: clerkUserId } = getAuth(req);

      if (!clerkUserId) {
        res.status(401).json({
          success: false,
          message: "Authentication required.",
        });
        return;
      }

      const orderId = req.params.orderId;

      if (typeof orderId !== "string" || orderId.trim().length === 0) {
        res.status(400).json({
          success: false,
          message: "Invalid order ID.",
        });
        return;
      }
      const { status: nextStatus, note } = req.body as {
        status?: string;
        note?: string;
      };

      if (!nextStatus || typeof nextStatus !== "string") {
        res.status(400).json({
          success: false,
          message: "A valid status is required.",
        });
        return;
      }
      const validStatuses = [
        "ACCEPTED",
        "PREPARING",
        "READY",
        "AWAITING_DELIVERY_PARTNER",
        "HANDED_OFF",
        "CANCELLED",
      ];

      if (!validStatuses.includes(nextStatus)) {
        res.status(400).json({
          success: false,
          message: "Invalid order status.",
        });
        return;
      }

      if (
        note !== undefined &&
        (typeof note !== "string" || note.trim().length > 500)
      ) {
        res.status(400).json({
          success: false,
          message: "Note must be a string with at most 500 characters.",
        });
        return;
      }

      // Resolve the Clerk account to the internal user.
      const user = await prisma.user.findUnique({
        where: {
          clerkUserId,
        },
        select: {
          id: true,
          isActive: true,
          outletStaff: {
            where: {
              isActive: true,
              role: {
                in: ["MANAGER", "KITCHEN_STAFF"],
              },
            },
            select: {
              outletId: true,
            },
          },
        },
      });

      if (!user || !user.isActive) {
        res.status(403).json({
          success: false,
          message: "Active staff profile required.",
        });
        return;
      }

      const outletIds = user.outletStaff.map(
        (assignment) => assignment.outletId,
      );

      if (outletIds.length === 0) {
        res.status(403).json({
          success: false,
          message: "No active kitchen outlet assignment found.",
        });
        return;
      }

      // Only allow updating orders from the staff member's assigned outlets.
      const updatedOrder = await prisma.$transaction(async (tx) => {
        const order = await tx.order.findFirst({
          where: {
            id: orderId,
            outletId: {
              in: outletIds,
            },
          },
          select: {
            id: true,
            orderNumber: true,
            outletId: true,
            status: true,
          },
        });

        if (!order) {
          return {
            error: "ORDER_NOT_FOUND",
          } as const;
        }

        const allowedTransitions =
          ALLOWED_STATUS_TRANSITIONS[order.status] ?? [];

        if (!allowedTransitions.includes(nextStatus)) {
          return {
            error: "INVALID_STATUS_TRANSITION",
            currentStatus: order.status,
          } as const;
        }

        const updated = await tx.order.update({
          where: {
            id: order.id,
          },
          data: {
            status: nextStatus as
              | "ACCEPTED"
              | "PREPARING"
              | "READY"
              | "AWAITING_DELIVERY_PARTNER"
              | "HANDED_OFF"
              | "CANCELLED",

            ...(nextStatus === "ACCEPTED" && {
              acceptedAt: new Date(),
            }),

            ...(nextStatus === "READY" && {
              readyAt: new Date(),
            }),

            ...(nextStatus === "HANDED_OFF" && {
              handedOffAt: new Date(),
            }),

            ...(nextStatus === "CANCELLED" && {
              cancelledAt: new Date(),
            }),
          },
          include: {
            outlet: {
              select: {
                id: true,
                name: true,
                code: true,
              },
            },
            items: {
              include: {
                addons: true,
              },
            },
            statusHistory: {
              orderBy: {
                createdAt: "asc",
              },
            },
          },
        });

        await tx.orderStatusHistory.create({
          data: {
            orderId: order.id,
            fromStatus: order.status,
            toStatus: nextStatus as
              | "ACCEPTED"
              | "PREPARING"
              | "READY"
              | "AWAITING_DELIVERY_PARTNER"
              | "HANDED_OFF"
              | "CANCELLED",
            changedByUserId: user.id,
            note: typeof note === "string" ? note.trim() || null : null,
          },
        });

        return {
          order: updated,
        } as const;
      });

      if ("error" in updatedOrder) {
        if (updatedOrder.error === "ORDER_NOT_FOUND") {
          res.status(404).json({
            success: false,
            message: "Order not found for your assigned outlet.",
          });
          return;
        }

        res.status(400).json({
          success: false,
          message: `Cannot transition order from ${updatedOrder.currentStatus} to ${nextStatus}.`,
        });
        return;
      }

      const io = req.app.get("io") as Server | undefined;

      io?.to(`customer:${updatedOrder.order.userId}`).emit(
        "order.status.updated",
        {
          orderId: updatedOrder.order.id,
          status: updatedOrder.order.status,
          updatedAt: new Date().toISOString(),
        },
      );

      res.status(200).json({
        success: true,
        message: "Order status updated successfully.",
        order: updatedOrder.order,
      });
    } catch (error) {
      next(error);
    }
  },
);
// POST /api/kitchen/orders/:orderId/notes
// Add a kitchen note to an order belonging to the staff member's assigned outlet.
kitchenRouter.post(
  "/orders/:orderId/notes",
  requireAuth,
  async (req, res, next) => {
    try {
      const { userId: clerkUserId } = getAuth(req);

      if (!clerkUserId) {
        res.status(401).json({
          success: false,
          message: "Authentication required.",
        });
        return;
      }

      const orderId = req.params.orderId;
      if (typeof orderId !== "string" || orderId.trim().length === 0) {
        res.status(400).json({
          success: false,
          message: "Invalid order ID.",
        });
        return;
      }

      const { note } = req.body as { note?: unknown };

      if (typeof note !== "string" || note.trim().length === 0) {
        res.status(400).json({
          success: false,
          message: "A kitchen note is required.",
        });
        return;
      }

      if (note.trim().length > 500) {
        res.status(400).json({
          success: false,
          message: "Kitchen note must be at most 500 characters.",
        });
        return;
      }

      const user = await prisma.user.findUnique({
        where: { clerkUserId },
        select: {
          id: true,
          isActive: true,
          outletStaff: {
            where: {
              isActive: true,
              role: { in: ["MANAGER", "KITCHEN_STAFF"] },
            },
            select: { outletId: true },
          },
        },
      });

      if (!user || !user.isActive) {
        res.status(403).json({
          success: false,
          message: "Active staff profile required.",
        });
        return;
      }

      const outletIds = user.outletStaff.map(
        (assignment) => assignment.outletId,
      );

      if (outletIds.length === 0) {
        res.status(403).json({
          success: false,
          message: "No active kitchen outlet assignment found.",
        });
        return;
      }

      const order = await prisma.order.findFirst({
        where: {
          id: orderId,
          outletId: { in: outletIds },
        },
        select: { id: true },
      });

      if (!order) {
        res.status(404).json({
          success: false,
          message: "Order not found for your assigned outlet.",
        });
        return;
      }

      const kitchenNote = await prisma.kitchenOrderNote.create({
        data: {
          orderId: order.id,
          note: note.trim(),
          createdByUserId: user.id,
        },
      });

      res.status(201).json({
        success: true,
        message: "Kitchen note added successfully.",
        note: kitchenNote,
      });
    } catch (error) {
      next(error);
    }
  },
);
export default kitchenRouter;
