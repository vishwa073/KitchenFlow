import { Router } from "express";
import { getAuth } from "@clerk/express";
import { prisma } from "../../lib/prisma.js";
import { requireAuth } from "../../middleware/require-auth.js";

const cartRouter = Router();

type AddCartItemBody = {
  outletId?: unknown;
  outletMenuItemId?: unknown;
  outletVariantPriceId?: unknown;
  quantity?: unknown;
  addons?: unknown;
};

type AddonInput = {
  outletAddonPriceId: string;
  quantity: number;
};

function isNonEmptyString(value: unknown): value is string {
  return typeof value === "string" && value.trim().length > 0;
}

function parseAddons(value: unknown): AddonInput[] | null {
  if (value === undefined) return [];
  if (!Array.isArray(value)) return null;

  const addons: AddonInput[] = [];

  for (const addon of value) {
    if (
      !addon ||
      typeof addon !== "object" ||
      !isNonEmptyString(addon.outletAddonPriceId) ||
      !Number.isInteger(addon.quantity) ||
      addon.quantity < 1
    ) {
      return null;
    }

    addons.push({
      outletAddonPriceId: addon.outletAddonPriceId,
      quantity: addon.quantity,
    });
  }

  // Reject duplicate addon IDs in the same request.
  const addonIds = addons.map((addon) => addon.outletAddonPriceId);
  if (new Set(addonIds).size !== addonIds.length) return null;

  return addons;
}

cartRouter.post("/items", requireAuth, async (req, res, next) => {
  try {
    const { userId: clerkUserId } = getAuth(req);

    if (!clerkUserId) {
      res.status(401).json({
        success: false,
        message: "Authentication required.",
      });
      return;
    }

    const body = req.body as AddCartItemBody;

    if (
      !isNonEmptyString(body.outletId) ||
      !isNonEmptyString(body.outletMenuItemId) ||
      !isNonEmptyString(body.outletVariantPriceId) ||
      !Number.isInteger(body.quantity) ||
      (body.quantity as number) < 1 ||
      (body.quantity as number) > 99
    ) {
      res.status(400).json({
        success: false,
        message:
          "Provide outletId, outletMenuItemId, outletVariantPriceId, and a quantity between 1 and 99.",
      });
      return;
    }

    const addons = parseAddons(body.addons);

    if (!addons) {
      res.status(400).json({
        success: false,
        message: "Invalid add-ons. Each add-on needs an ID and quantity.",
      });
      return;
    }

    const user = await prisma.user.findUnique({
      where: { clerkUserId },
      select: { id: true, isActive: true },
    });

    if (!user || !user.isActive) {
      res.status(404).json({
        success: false,
        message: "User profile not found or inactive. Call /api/auth/me first.",
      });
      return;
    }

    const result = await prisma.$transaction(async (tx) => {
      // Validate the outlet-specific menu item and selected price.
      const variantPrice = await tx.outletVariantPrice.findFirst({
        where: {
          id: body.outletVariantPriceId as string,
          isAvailable: true,
          outletMenuItemId: body.outletMenuItemId as string,
          outletMenuItem: {
            outletId: body.outletId as string,
            isAvailable: true,
            outlet: {
              isActive: true,
            },
            menuItem: {
              isActive: true,
              isPublished: true,
            },
          },
          variant: {
            isActive: true,
          },
        },
        select: {
          id: true,
          price: true,
          outletMenuItemId: true,
          outletMenuItem: {
            select: {
              outletId: true,
            },
          },
        },
      });

      if (!variantPrice) {
        return {
          error: "The selected menu item or variant is unavailable.",
          status: 400,
        };
      }

      // Validate all selected add-ons belong to this outlet and are available.
      const addonPrices =
        addons.length > 0
          ? await tx.outletAddonPrice.findMany({
              where: {
                id: {
                  in: addons.map((addon) => addon.outletAddonPriceId),
                },
                outletId: body.outletId as string,
                isAvailable: true,
                addon: {
                  isActive: true,
                },
              },
              select: {
                id: true,
                price: true,
              },
            })
          : [];

      if (addonPrices.length !== addons.length) {
        return {
          error: "One or more selected add-ons are unavailable.",
          status: 400,
        };
      }

      // Find this user's active cart. An active cart belongs to one outlet.
      let cart = await tx.cart.findFirst({
        where: {
          userId: user.id,
          isActive: true,
        },
        include: {
          items: true,
        },
      });

      if (cart && cart.outletId !== (body.outletId as string)) {
        return {
          error:
            "Your active cart belongs to another outlet. Clear it before ordering from a different outlet.",
          status: 409,
        };
      }

      if (!cart) {
        cart = await tx.cart.create({
          data: {
            userId: user.id,
            outletId: body.outletId as string,
            isActive: true,
          },
          include: {
            items: true,
          },
        });
      }

      // Create the cart item using the price resolved from the database.
      const cartItem = await tx.cartItem.create({
        data: {
          cartId: cart.id,
          outletMenuItemId: variantPrice.outletMenuItemId,
          outletVariantPriceId: variantPrice.id,
          quantity: body.quantity as number,
          unitPrice: variantPrice.price,
          addons: {
            create: addons.map((addon) => {
              const addonPrice = addonPrices.find(
                (price) => price.id === addon.outletAddonPriceId,
              );

              return {
                outletAddonPriceId: addon.outletAddonPriceId,
                quantity: addon.quantity,
                unitPrice: addonPrice!.price,
              };
            }),
          },
        },
        include: {
          addons: {
            include: {
              addonPrice: {
                include: {
                  addon: true,
                },
              },
            },
          },
          variantPrice: {
            include: {
              variant: true,
            },
          },
          outletMenuItem: {
            include: {
              menuItem: true,
            },
          },
        },
      });

      return {
        cartId: cart.id,
        outletId: cart.outletId,
        item: cartItem,
      };
    });

    if ("error" in result) {
      const errorResult = result as {
        error: string;
        status: number;
      };

      res.status(errorResult.status).json({
        success: false,
        message: errorResult.error,
      });
      return;
    }

    res.status(201).json({
      success: true,
      message: "Item added to cart.",
      cart: result,
    });
  } catch (error) {
    next(error);
  }
});

export default cartRouter;
