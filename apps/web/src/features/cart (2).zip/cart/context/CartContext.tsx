import { useAuth } from "@clerk/react";
import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useState,
  type ReactNode,
} from "react";

import type { Cart, CartItem } from "../types/cart";
import type { MenuItem, MenuVariant } from "../../menu/types/menu";

import { useApi } from "../../../lib/api";
import { getCartItemCount, getCartSubtotal } from "../utils/cartUtils";

interface CartContextType {
  cart: Cart;
  cartCount: number;
  subtotal: number;
  loading: boolean;
  refreshCart: () => Promise<void>;
  addItem: (item: MenuItem, variant: MenuVariant) => Promise<void>;
  updateQuantity: (cartItemId: string, quantity: number) => Promise<void>;
  removeItem: (cartItemId: string) => Promise<void>;
  clearCart: () => Promise<void>;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

type ApiCartItem = {
  id: string;
  quantity: number;
  unitPrice: number | string;
  outletMenuItem: {
    id: string;
    outletId: string;
    menuItem: {
      id: string;
      name: string;
      description: string | null;
      imageUrl: string | null;
      categoryId: string;
      foodType: string;
      isActive: boolean;
    };
  };
  variantPrice: {
    id: string;
    price: number | string;
    variant: {
      id: string;
      name: string;
      isActive: boolean;
    };
  };
};

type ApiCart = {
  id: string;
  outletId: string;
  items: ApiCartItem[];
};

function toNumber(value: number | string): number {
  return Number(value);
}

function mapApiCartItem(apiItem: ApiCartItem): CartItem {
  const dbMenuItem = apiItem.outletMenuItem.menuItem;
  const dbVariant = apiItem.variantPrice.variant;

  const menuItem: MenuItem = {
    // This is the outlet-specific menu item ID used by POST /items.
    id: apiItem.outletMenuItem.id,
    outletId: apiItem.outletMenuItem.outletId,
    menuItemId: dbMenuItem.id,
    name: dbMenuItem.name,
    description: dbMenuItem.description ?? "",
    image: dbMenuItem.imageUrl ?? "",
    price: toNumber(apiItem.variantPrice.price),
    category: dbMenuItem.categoryId,
    isAvailable: true,
    isVegetarian: dbMenuItem.foodType.toLowerCase().includes("vegetarian"),
    isPopular: false,
  };

  const selectedVariant: MenuVariant = {
    // This is the outlet-specific variant price ID used by POST /items.
    id: apiItem.variantPrice.id,
    variantId: dbVariant.id,
    name: dbVariant.name,
    price: toNumber(apiItem.variantPrice.price),
  };

  return {
    id: apiItem.id,
    menuItem,
    selectedVariant,
    quantity: apiItem.quantity,
  };
}

const emptyCart: Cart = {
  outletId: "",
  items: [],
};

export function CartProvider({ children }: { children: ReactNode }) {
  const { apiFetch } = useApi();
  const { isLoaded, isSignedIn } = useAuth();
  const [cart, setCart] = useState<Cart>(emptyCart);
  const [loading, setLoading] = useState(true);

  const refreshCart = useCallback(async () => {
    const response = await apiFetch("/api/cart");

    const data = (await response.json()) as {
      success?: boolean;
      message?: string;
      cart?: ApiCart | null;
    };

    if (!response.ok || data.success === false) {
      throw new Error(data.message ?? "Unable to fetch cart.");
    }

    if (!data.cart) {
      setCart(emptyCart);
      return;
    }

    setCart({
      id: data.cart.id,
      outletId: data.cart.outletId,
      items: data.cart.items.map(mapApiCartItem),
    });
  }, [apiFetch]);

  useEffect(() => {
  if (!isLoaded) return;

  if (!isSignedIn) {
    setCart(emptyCart);
    setLoading(false);
    return;
  }

  let mounted = true;

  const loadCart = async () => {
    setLoading(true);

    try {
      await refreshCart();
    } catch (error) {
      if (mounted) {
        console.error("Unable to load cart:", error);
      }
    } finally {
      if (mounted) {
        setLoading(false);
      }
    }
  };

  void loadCart();

  return () => {
    mounted = false;
  };
}, [isLoaded, isSignedIn, refreshCart]);

  const addItem = async (item: MenuItem, variant: MenuVariant) => {
    if (cart.outletId && cart.outletId !== item.outletId) {
      throw new Error("Your cart already contains items from another outlet.");
    }

    const response = await apiFetch("/api/cart/items", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        outletId: item.outletId,
        outletMenuItemId: item.id,
        outletVariantPriceId: variant.id,
        quantity: 1,
        addons: [],
      }),
    });

    const data = (await response.json()) as {
      success?: boolean;
      message?: string;
    };

    if (!response.ok || data.success === false) {
      throw new Error(data.message ?? "Unable to add item to cart.");
    }

    await refreshCart();
  };

  const updateQuantity = async (cartItemId: string, quantity: number) => {
    if (quantity <= 0) {
      await removeItem(cartItemId);
      return;
    }

    const response = await apiFetch(
      `/api/cart/items/${encodeURIComponent(cartItemId)}`,
      {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ quantity }),
      },
    );

    const data = (await response.json()) as {
      success?: boolean;
      message?: string;
    };

    if (!response.ok || data.success === false) {
      throw new Error(data.message ?? "Unable to update quantity.");
    }

    await refreshCart();
  };

  const removeItem = async (cartItemId: string) => {
    const response = await apiFetch(
      `/api/cart/items/${encodeURIComponent(cartItemId)}`,
      {
        method: "DELETE",
      },
    );

    const data = (await response.json()) as {
      success?: boolean;
      message?: string;
    };

    if (!response.ok || data.success === false) {
      throw new Error(data.message ?? "Unable to remove item.");
    }

    await refreshCart();
  };

  const clearCart = async () => {
    const response = await apiFetch("/api/cart", {
      method: "DELETE",
    });

    const data = (await response.json()) as {
      success?: boolean;
      message?: string;
    };

    if (!response.ok || data.success === false) {
      throw new Error(data.message ?? "Unable to clear cart.");
    }

    setCart(emptyCart);
  };

  return (
    <CartContext.Provider
      value={{
        cart,
        cartCount: getCartItemCount(cart),
        subtotal: getCartSubtotal(cart),
        loading,
        refreshCart,
        addItem,
        updateQuantity,
        removeItem,
        clearCart,
      }}
    >
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);

  if (!context) {
    throw new Error("useCart must be used within CartProvider");
  }

  return context;
}
