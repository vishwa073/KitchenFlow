import type {
  MenuItem,
  MenuVariant,
} from "../../menu/types/menu";

export interface CartItem {
  menuItem: MenuItem;
  selectedVariant: MenuVariant;
  quantity: number;
}

export interface Cart {
  outletId: string;
  items: CartItem[];
}