
import {
  createContext,
  useContext,
  useState,
  type ReactNode,
} from "react";

import type { Cart } from "../types/cart";
import type {
  MenuItem,
  MenuVariant,
} from "../../menu/types/menu";

import { useApi } from "../../../lib/api";
import {
  getCartItemCount,
  getCartSubtotal,
} from "../utils/cartUtils";

interface CartContextType {
  cart: Cart;
  cartCount: number;
  subtotal: number;
  addItem: (item: MenuItem, variant: MenuVariant) => Promise<void>;
  updateQuantity: (variantPriceId: string, quantity: number) => void;
  removeItem: (variantPriceId: string) => void;
  clearCart: () => void;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export function CartProvider({ children }: { children: ReactNode }) {
  const { apiFetch } = useApi();

  const [cart, setCart] = useState<Cart>({
    outletId: "",
    items: [],
  });

  const addItem = async (item: MenuItem, variant: MenuVariant) => {
    if (cart.outletId && cart.outletId !== item.outletId) {
      throw new Error("Your cart already contains items from another outlet.");
    }

    const response = await apiFetch("/api/cart/items", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        outletId: item.outletId,
        outletMenuItemId: item.id,
        outletVariantPriceId: variant.id,
        quantity: 1,
        addons: [],
      }),
    });

    const data = (await response.json()) as {
      success?: boolean;
      message?: string;
    };

    if (!response.ok || data.success === false) {
      throw new Error(data.message ?? "Unable to add item to cart.");
    }

    setCart((currentCart) => {
      const existingItem = currentCart.items.find(
        (cartItem) => cartItem.selectedVariant.id === variant.id,
      );

      const updatedItems = existingItem
        ? currentCart.items.map((cartItem) =>
            cartItem.selectedVariant.id === variant.id
              ? {
                  ...cartItem,
                  quantity: cartItem.quantity + 1,
                }
              : cartItem,
          )
        : [
            ...currentCart.items,
            {
              menuItem: item,
              selectedVariant: variant,
              quantity: 1,
            },
          ];

      return {
        outletId: item.outletId,
        items: updatedItems,
      };
    });
  };

  const updateQuantity = (
    variantPriceId: string,
    quantity: number,
  ) => {
    if (quantity <= 0) {
      removeItem(variantPriceId);
      return;
    }

    setCart((currentCart) => ({
      ...currentCart,
      items: currentCart.items.map((item) =>
        item.selectedVariant.id === variantPriceId
          ? { ...item, quantity }
          : item,
      ),
    }));
  };

  const removeItem = (variantPriceId: string) => {
    setCart((currentCart) => {
      const items = currentCart.items.filter(
        (item) => item.selectedVariant.id !== variantPriceId,
      );

      return {
        outletId: items.length === 0 ? "" : currentCart.outletId,
        items,
      };
    });
  };

  const clearCart = () => {
    setCart({ outletId: "", items: [] });
  };

  return (
    <CartContext.Provider
      value={{
        cart,
        cartCount: getCartItemCount(cart),
        subtotal: getCartSubtotal(cart),
        addItem,
        updateQuantity,
        removeItem,
        clearCart,
      }}
    >
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);

  if (!context) {
    throw new Error("useCart must be used within CartProvider");
  }

  return context;
}
