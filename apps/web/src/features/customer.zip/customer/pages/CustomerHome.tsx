import { useParams } from "react-router-dom";
import MenuPage from "../../menu/MenuPage";
import CustomerSection from "../components/CustomerSection";

export default function CustomerHome() {
  const { outletId } = useParams<{ outletId: string }>();

  if (!outletId) {
    return (
      <div className="p-6 text-center text-red-600">
        Outlet ID is missing.
      </div>
    );
  }

  return (
    <div className="mx-auto w-full max-w-7xl px-4 py-6 sm:py-8">
      <CustomerSection
        title="Explore the menu"
        description="Choose your favorites and add them to your cart."
      >
        {/* Keep the existing MenuPage unchanged */}
        <MenuPage />
      </CustomerSection>
    </div>
  );
}