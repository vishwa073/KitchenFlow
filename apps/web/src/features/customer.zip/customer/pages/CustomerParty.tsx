
import { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import {
  UsersRound,
  Copy,
  Plus,
  Minus,
  ArrowRight,
} from "lucide-react";
import CustomerSection from "../components/CustomerSection";

export default function CustomerParty() {
  const navigate = useNavigate();
  const { outletId } = useParams<{ outletId: string }>();

  const [partySize, setPartySize] = useState(4);
  const [partyName, setPartyName] = useState("");

  function handleStartParty() {
    // Temporary UI flow. Group cart/session creation will be integrated later.
    navigate(`/customer/${outletId}`);
  }

  return (
    <div className="mx-auto w-full max-w-3xl px-4 py-6 sm:py-8">
      <CustomerSection
        title="Party Order"
        description="Order together with friends, family, or colleagues."
      >
        <div className="overflow-hidden rounded-2xl border border-stone-200 bg-white">
          <div className="bg-gradient-to-br from-orange-50 to-amber-100 p-6 sm:p-8">
            <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-white text-orange-600 shadow-sm">
              <UsersRound size={30} />
            </div>

            <h3 className="mt-5 text-xl font-bold text-stone-900">
              Make it a group order
            </h3>

            <p className="mt-2 max-w-lg text-sm leading-6 text-stone-600">
              Create a shared party order so everyone can add their
              favorite food to the same order.
            </p>
          </div>

          <div className="space-y-5 p-5 sm:p-6">
            <label className="block">
              <span className="mb-2 block text-sm font-semibold text-stone-700">
                Party name
              </span>

              <input
                type="text"
                value={partyName}
                onChange={(event) => setPartyName(event.target.value)}
                placeholder="e.g. Friday office lunch"
                className="w-full rounded-xl border border-stone-200 px-4 py-3 text-sm outline-none transition focus:border-orange-500 focus:ring-2 focus:ring-orange-100"
              />
            </label>

            <div>
              <span className="mb-2 block text-sm font-semibold text-stone-700">
                Number of people
              </span>

              <div className="flex items-center justify-between rounded-xl border border-stone-200 p-3">
                <div>
                  <p className="font-semibold text-stone-900">
                    Participants
                  </p>
                  <p className="text-sm text-stone-500">
                    Including you
                  </p>
                </div>

                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    disabled={partySize <= 2}
                    onClick={() =>
                      setPartySize((size) => Math.max(2, size - 1))
                    }
                    className="flex h-9 w-9 items-center justify-center rounded-full border border-stone-200 text-stone-700 disabled:opacity-40"
                    aria-label="Decrease participants"
                  >
                    <Minus size={16} />
                  </button>

                  <span className="w-6 text-center font-bold text-stone-900">
                    {partySize}
                  </span>

                  <button
                    type="button"
                    disabled={partySize >= 30}
                    onClick={() =>
                      setPartySize((size) => Math.min(30, size + 1))
                    }
                    className="flex h-9 w-9 items-center justify-center rounded-full border border-stone-200 text-stone-700 disabled:opacity-40"
                    aria-label="Increase participants"
                  >
                    <Plus size={16} />
                  </button>
                </div>
              </div>
            </div>

            <div className="rounded-xl bg-stone-50 p-4">
              <div className="flex items-start gap-3">
                <Copy size={18} className="mt-0.5 text-stone-500" />
                <div>
                  <p className="text-sm font-semibold text-stone-800">
                    Invite your group
                  </p>
                  <p className="mt-1 text-sm leading-5 text-stone-500">
                    After creating your party, you’ll be able to share
                    an invite link with participants.
                  </p>
                </div>
              </div>
            </div>

            <button
              type="button"
              onClick={handleStartParty}
              className="flex w-full items-center justify-center gap-2 rounded-xl bg-orange-600 px-5 py-3.5 font-semibold text-white transition hover:bg-orange-700"
            >
              Start party order
              <ArrowRight size={18} />
            </button>
          </div>
        </div>
      </CustomerSection>
    </div>
  );
}
