import { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import {
  ArrowLeft,
  Minus,
  Plus,
  ShoppingBag,
  Users,
  PartyPopper,
  Clock3,
  Sparkles,
} from "lucide-react";

type PartyMenuItem = {
  id: string;
  name: string;
  description: string;
  serves: string;
  price: number;
  category: string;
};

const partyMenu: PartyMenuItem[] = [
  {
    id: "party-biryani-1",
    name: "Chicken Bucket Biryani",
    description: "Aromatic dum biryani, packed generously for sharing.",
    serves: "5–6 people",
    price: 1499,
    category: "Biryani Buckets",
  },
  {
    id: "party-biryani-2",
    name: "Family Pack Chicken Biryani",
    description: "A delicious family-sized biryani pack.",
    serves: "3–4 people",
    price: 899,
    category: "Family Packs",
  },
  {
    id: "party-biryani-3",
    name: "Grand Chicken Biryani Bucket",
    description: "The ultimate biryani bucket for a bigger gathering.",
    serves: "8–10 people",
    price: 2499,
    category: "Biryani Buckets",
  },
  {
    id: "party-combo-1",
    name: "Party Starter Combo",
    description: "A tempting selection of crowd-favorite starters.",
    serves: "4–5 people",
    price: 1199,
    category: "Party Combos",
  },
  {
    id: "party-combo-2",
    name: "Biryani & Starter Party Combo",
    description: "Biryani and starters together for the perfect party.",
    serves: "6–8 people",
    price: 2199,
    category: "Party Combos",
  },
  {
    id: "party-combo-3",
    name: "Family Feast Combo",
    description: "Biryani, starters, and sides for a complete feast.",
    serves: "5–6 people",
    price: 1799,
    category: "Family Packs",
  },
];

const categories = [...new Set(partyMenu.map((item) => item.category))];

export default function PartyPage() {
  const { outletId } = useParams<{ outletId: string }>();
  const navigate = useNavigate();

  const [quantities, setQuantities] = useState<Record<string, number>>({});

  const updateQuantity = (itemId: string, change: number) => {
    setQuantities((current) => {
      const nextQuantity = Math.max(0, (current[itemId] ?? 0) + change);

      return {
        ...current,
        [itemId]: nextQuantity,
      };
    });
  };

  const selectedItems = partyMenu.filter(
    (item) => (quantities[item.id] ?? 0) > 0,
  );

  const totalItems = selectedItems.reduce(
    (total, item) => total + quantities[item.id],
    0,
  );

  const subtotal = selectedItems.reduce(
    (total, item) => total + item.price * quantities[item.id],
    0,
  );

  const formatPrice = (price: number) =>
    `₹${price.toLocaleString("en-IN")}`;

  return (
    <main className="min-h-screen bg-[#faf8f5] pb-40 text-stone-900">
      {/* Header */}
      <header className="sticky top-0 z-30 border-b border-stone-200/80 bg-[#faf8f5]/95 backdrop-blur-md">
        <div className="mx-auto flex max-w-7xl items-center gap-3 px-4 py-3 sm:px-6 lg:px-8">
          <button
            type="button"
            onClick={() => navigate(`/customer/${outletId}`)}
            className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-stone-200 bg-white transition hover:bg-stone-100"
            aria-label="Back to customer home"
          >
            <ArrowLeft size={19} />
          </button>

          <div className="min-w-0">
            <h1 className="truncate text-base font-bold sm:text-lg">
              Party Orders
            </h1>
            <p className="text-xs text-stone-500">
              Big gatherings, bigger flavors
            </p>
          </div>

          <div className="ml-auto flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-orange-100 text-orange-600">
            <PartyPopper size={20} />
          </div>
        </div>
      </header>

      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Hero */}
        <section className="relative mt-5 overflow-hidden rounded-[28px] bg-gradient-to-br from-[#f97316] via-[#ea580c] to-[#c2410c] px-5 py-7 text-white shadow-sm sm:mt-7 sm:px-8 sm:py-9 lg:px-10">
          {/* Decorative circles */}
          <div className="pointer-events-none absolute -right-12 -top-16 h-52 w-52 rounded-full border-[30px] border-white/10" />
          <div className="pointer-events-none absolute -bottom-24 right-24 h-44 w-44 rounded-full bg-white/5" />
          <Sparkles
            className="pointer-events-none absolute right-8 top-8 text-orange-100/70"
            size={24}
          />

          <div className="relative z-10 max-w-2xl">
            <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/15 px-3 py-1.5 text-xs font-semibold tracking-wide text-orange-50">
              <PartyPopper size={14} />
              KITCHENFLOW PARTY
            </div>

            <h2 className="max-w-xl text-3xl font-extrabold leading-tight tracking-tight sm:text-4xl lg:text-5xl">
              Make every gathering
              <span className="block text-orange-100">a little tastier.</span>
            </h2>

            <p className="mt-3 max-w-lg text-sm leading-6 text-orange-50 sm:text-base">
              From family dinners to big celebrations, find generous portions
              and combos made to bring everyone together.
            </p>

            <div className="mt-6 flex flex-wrap gap-2">
              <span className="inline-flex items-center gap-2 rounded-full bg-white/15 px-3 py-2 text-xs font-medium text-white sm:text-sm">
                <Users size={15} />
                Group-sized portions
              </span>

              <span className="inline-flex items-center gap-2 rounded-full bg-white/15 px-3 py-2 text-xs font-medium text-white sm:text-sm">
                <Clock3 size={15} />
                Pre-order for your event
              </span>
            </div>
          </div>
        </section>

        {/* Menu heading */}
        <section className="mb-5 mt-8 sm:mt-10">
          <div className="flex items-end justify-between gap-3">
            <div>
              <p className="text-xs font-bold uppercase tracking-[0.16em] text-orange-600">
                Made for sharing
              </p>
              <h2 className="mt-1 text-2xl font-extrabold tracking-tight sm:text-3xl">
                Party menu
              </h2>
              <p className="mt-1 text-sm text-stone-500">
                Choose your favorites for the whole crew.
              </p>
            </div>

            <span className="mb-1 shrink-0 rounded-full bg-white px-3 py-1.5 text-xs font-semibold text-stone-500 ring-1 ring-stone-200">
              {partyMenu.length} items
            </span>
          </div>
        </section>

        {/* Category sections */}
        {categories.map((category) => {
          const categoryItems = partyMenu.filter(
            (item) => item.category === category,
          );

          return (
            <section key={category} className="mb-8 sm:mb-10">
              <div className="mb-4 flex items-center gap-3">
                <h3 className="text-lg font-bold tracking-tight sm:text-xl">
                  {category}
                </h3>
                <div className="h-px flex-1 bg-stone-200" />
              </div>

              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3">
                {categoryItems.map((item) => {
                  const quantity = quantities[item.id] ?? 0;

                  return (
                    <article
                      key={item.id}
                      className="group flex min-w-0 flex-col overflow-hidden rounded-2xl border border-stone-200/80 bg-white shadow-[0_2px_8px_rgba(28,25,23,0.03)] transition duration-200 hover:-translate-y-0.5 hover:border-orange-200 hover:shadow-[0_8px_24px_rgba(28,25,23,0.06)]"
                    >
                      {/* Card visual */}
                      <div className="relative flex h-40 items-center justify-center overflow-hidden bg-gradient-to-br from-orange-50 via-amber-50 to-orange-100 sm:h-44">
                        <div className="absolute -right-8 -top-8 h-32 w-32 rounded-full bg-white/50" />
                        <div className="absolute -bottom-10 -left-5 h-28 w-28 rounded-full bg-orange-200/20" />

                        <div className="relative flex h-24 w-24 items-center justify-center rounded-full border border-white/80 bg-white/70 shadow-sm transition duration-300 group-hover:scale-105 sm:h-28 sm:w-28">
                          <span className="text-5xl drop-shadow-sm sm:text-6xl">
                            🍛
                          </span>
                        </div>

                        <span className="absolute left-3 top-3 rounded-full border border-white/80 bg-white/80 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wide text-orange-700 backdrop-blur-sm">
                          Party size
                        </span>
                      </div>

                      {/* Card content */}
                      <div className="flex flex-1 flex-col p-4 sm:p-5">
                        <div className="flex-1">
                          <h4 className="text-base font-bold leading-snug text-stone-900 sm:text-lg">
                            {item.name}
                          </h4>

                          <p className="mt-1.5 min-h-[40px] text-sm leading-5 text-stone-500">
                            {item.description}
                          </p>

                          <div className="mt-3 inline-flex items-center gap-1.5 rounded-lg bg-stone-50 px-2.5 py-1.5 text-xs font-semibold text-stone-600">
                            <Users size={14} className="text-orange-600" />
                            Serves {item.serves.replace(" people", "")}
                          </div>
                        </div>

                        <div className="mt-5 flex items-center justify-between gap-3 border-t border-stone-100 pt-4">
                          <div>
                            <p className="text-[10px] font-semibold uppercase tracking-wider text-stone-400">
                              Price
                            </p>
                            <p className="mt-0.5 text-xl font-extrabold tracking-tight text-stone-900">
                              {formatPrice(item.price)}
                            </p>
                          </div>

                          {quantity === 0 ? (
                            <button
                              type="button"
                              onClick={() => updateQuantity(item.id, 1)}
                              className="inline-flex items-center gap-2 rounded-xl border border-orange-600 bg-white px-4 py-2.5 text-sm font-bold text-orange-600 transition hover:bg-orange-600 hover:text-white"
                            >
                              <Plus size={16} />
                              Add
                            </button>
                          ) : (
                            <div className="inline-flex items-center gap-3 rounded-xl bg-orange-600 px-2.5 py-2 text-white shadow-sm">
                              <button
                                type="button"
                                onClick={() => updateQuantity(item.id, -1)}
                                className="rounded-lg p-1 transition hover:bg-white/15"
                                aria-label={`Remove one ${item.name}`}
                              >
                                <Minus size={16} />
                              </button>

                              <span className="min-w-4 text-center text-sm font-bold">
                                {quantity}
                              </span>

                              <button
                                type="button"
                                onClick={() => updateQuantity(item.id, 1)}
                                className="rounded-lg p-1 transition hover:bg-white/15"
                                aria-label={`Add one ${item.name}`}
                              >
                                <Plus size={16} />
                              </button>
                            </div>
                          )}
                        </div>
                      </div>
                    </article>
                  );
                })}
              </div>
            </section>
          );
        })}

        {/* Bottom note */}
        <div className="mb-6 rounded-2xl border border-orange-100 bg-orange-50/70 px-4 py-4 sm:px-5">
          <div className="flex items-start gap-3">
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-white text-orange-600">
              <Sparkles size={18} />
            </div>
            <div>
              <p className="text-sm font-bold text-stone-800">
                Planning a bigger celebration?
              </p>
              <p className="mt-1 text-xs leading-5 text-stone-600 sm:text-sm">
                Select your party packs and combos. You can review your
                selection before proceeding.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Floating party cart */}
      {totalItems > 0 && (
        <div className="fixed inset-x-0 bottom-[76px] z-40 px-3 sm:bottom-20 sm:px-5">
          <div className="mx-auto flex max-w-3xl items-center justify-between gap-3 rounded-2xl border border-stone-700 bg-stone-900 p-3.5 text-white shadow-[0_12px_40px_rgba(28,25,23,0.25)] sm:p-4">
            <div className="flex min-w-0 items-center gap-3">
              <div className="relative flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-orange-600">
                <ShoppingBag size={20} />

                <span className="absolute -right-1.5 -top-1.5 flex h-5 min-w-5 items-center justify-center rounded-full border-2 border-stone-900 bg-white px-1 text-[10px] font-extrabold text-stone-900">
                  {totalItems}
                </span>
              </div>

              <div className="min-w-0">
                <p className="truncate text-sm font-bold">
                  Your party selection
                </p>
                <p className="mt-0.5 text-xs text-stone-300">
                  {totalItems} {totalItems === 1 ? "item" : "items"} ·{" "}
                  <span className="font-semibold text-white">
                    {formatPrice(subtotal)}
                  </span>
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() =>
                navigate(`/customer/${outletId}/party/cart`, {
                  state: {
                    items: selectedItems.map((item) => ({
                      ...item,
                      quantity: quantities[item.id],
                    })),
                    subtotal,
                  },
                })
              }
              className="inline-flex shrink-0 items-center gap-2 rounded-xl bg-orange-600 px-4 py-3 text-xs font-bold text-white transition hover:bg-orange-700 sm:px-5 sm:text-sm"
            >
              View cart
              <ArrowLeft className="rotate-180" size={16} />
            </button>
          </div>
        </div>
      )}
    </main>
  );
}