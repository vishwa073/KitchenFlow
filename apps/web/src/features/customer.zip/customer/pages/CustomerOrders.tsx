import { useNavigate, useParams } from "react-router-dom";
import { ArrowRight, ClipboardList, Clock3 } from "lucide-react";
import CustomerSection from "../components/CustomerSection";

type OrderStatus = "Preparing" | "On the way" | "Delivered" | "Cancelled";

interface CustomerOrder {
  id: string;
  outletName: string;
  date: string;
  items: string[];
  total: number;
  status: OrderStatus;
}

const mockOrders: CustomerOrder[] = [
  {
    id: "KF-1001",
    outletName: "KitchenFlow Central",
    date: "Today, 12:30 PM",
    items: ["Paneer Biryani", "Masala Lemonade"],
    total: 289,
    status: "Preparing",
  },
  {
    id: "KF-1002",
    outletName: "KitchenFlow Central",
    date: "Yesterday, 7:15 PM",
    items: ["Veg Burger", "French Fries"],
    total: 249,
    status: "Delivered",
  },
];

const statusStyles: Record<OrderStatus, string> = {
  Preparing: "bg-amber-100 text-amber-700",
  "On the way": "bg-blue-100 text-blue-700",
  Delivered: "bg-emerald-100 text-emerald-700",
  Cancelled: "bg-red-100 text-red-700",
};

export default function CustomerOrders() {
  const navigate = useNavigate();
  const { outletId } = useParams<{ outletId: string }>();

  return (
    <div className="mx-auto w-full max-w-7xl px-4 py-6 sm:py-8">
      <CustomerSection
        title="Your orders"
        description="Track your current order and revisit your past orders."
      >
        {mockOrders.length === 0 ? (
          <div className="rounded-2xl border border-stone-200 bg-white px-6 py-12 text-center">
            <ClipboardList size={40} className="mx-auto text-stone-300" />
            <h3 className="mt-4 text-lg font-semibold text-stone-900">
              No orders yet
            </h3>
            <p className="mt-2 text-sm text-stone-500">
              Your orders will appear here after you place one.
            </p>

            <button
              type="button"
              onClick={() => navigate(`/customer/${outletId}`)}
              className="mt-5 rounded-xl bg-orange-600 px-5 py-3 font-semibold text-white hover:bg-orange-700"
            >
              Explore menu
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            {mockOrders.map((order) => (
              <article
                key={order.id}
                className="rounded-2xl border border-stone-200 bg-white p-4 sm:p-6"
              >
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <p className="text-sm text-stone-500">Order #{order.id}</p>
                    <h3 className="mt-1 font-bold text-stone-900">
                      {order.outletName}
                    </h3>
                    <p className="mt-1 flex items-center gap-2 text-sm text-stone-500">
                      <Clock3 size={15} />
                      {order.date}
                    </p>
                  </div>

                  <span
                    className={`rounded-full px-3 py-1.5 text-xs font-semibold ${statusStyles[order.status]}`}
                  >
                    {order.status}
                  </span>
                </div>

                <div className="mt-4 border-t border-stone-100 pt-4">
                  <p className="text-sm text-stone-600">
                    {order.items.join(", ")}
                  </p>

                  <div className="mt-4 flex items-center justify-between">
                    <p className="font-bold text-stone-900">
                      ₹{order.total.toFixed(2)}
                    </p>

                    <button
                      type="button"
                      onClick={() =>
                        navigate(`/orders/${order.id}`, {
                          state: {
                            returnTo: `/customer/${outletId}`,
                          },
                        })
                      }
                      className="inline-flex items-center gap-2 text-sm font-semibold text-orange-600 hover:text-orange-700"
                    >
                      View order
                      <ArrowRight size={16} />
                    </button>
                  </div>
                </div>
              </article>
            ))}
          </div>
        )}
      </CustomerSection>
    </div>
  );
}
